#!/bin/bash
while true; do
    echo "Hello, world!" >> /home/test.txt
    sleep 1
done